/**
 * Non-functional JS file to test for inclusion on page.
 */
