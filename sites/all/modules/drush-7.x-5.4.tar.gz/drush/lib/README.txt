Drush adds external libraries here; examples include the Console Table
and lightweight httpserver.

This directory should be writable by the first user who runs Drush so
that these dependencies can be downloaded.  It may be set to read-only
after that.
